//
//  BiographyApp.swift
//  Biography
//
//  Created by Enya Do on 3/8/23.
//

import SwiftUI

@main
struct BiographyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
